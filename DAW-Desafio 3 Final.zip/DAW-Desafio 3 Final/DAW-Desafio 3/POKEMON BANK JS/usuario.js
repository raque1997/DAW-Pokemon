// Datos del usuario predefinidos
const usuario = {
    nombre: "Ash Ketchum",
    pin: "1234",
    cuenta: "0987654321",
    saldo: 500.00
};

// Función para iniciar sesión
function login() {
    const usernameInput = document.getElementById("user").value;
    const pinInput = document.getElementById("pw").value;

    // Validar que el nombre de usuario y el PIN coincidan con los datos almacenados
    if (usernameInput.toLowerCase() === usuario.nombre.toLowerCase() && pinInput === usuario.pin) {
        // Guardar datos del usuario en LocalStorage
        localStorage.setItem("usuario", JSON.stringify(usuario));

        // Redirigir a la página del menú
        window.location.href = "menu.html";
    } else {
        Swal.fire({
            title: 'Error de inicio de sesión',
            text: 'Usuario o PIN incorrecto. Inténtalo nuevamente.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
        });
    }
}


// Al cargar la página del menú, recuperar y mostrar los datos del usuario
window.onload = function() {
    const userData = JSON.parse(localStorage.getItem("usuario"));
    if (userData) {
        document.getElementById("username").innerText = `${userData.nombre}`;
        document.getElementById("account").innerText = `${userData.cuenta}`;
        document.getElementById("balance").innerText = userData.saldo.toFixed(2); // Mostrar saldo con dos decimales
    }
};






