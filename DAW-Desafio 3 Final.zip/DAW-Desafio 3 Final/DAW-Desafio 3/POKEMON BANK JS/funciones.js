// Función para generar el PDF
function generatePDF(username, amount, serviceType) {
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        doc.setFontSize(16);
        doc.text(20, 20, 'Comprobante de Pago');
        doc.setFontSize(12);
        doc.text(20, 40, `Nombre: ${username}`);
        doc.text(20, 50, `Servicio Pagado: ${serviceType}`);
        doc.text(20, 60, `Monto Pagado: ${amount}`);
        doc.text(20, 80, `Fecha: ${new Date().toLocaleString()}`);

        doc.save('comprobante_pago.pdf'); // Descarga el archivo PDF
    } catch (error) {
        console.error("Error al generar el PDF:", error);
    }
}

// Función para manejar la impresión del PDF
let lastPaymentData = null; // Esta variable debe ser actualizada al realizar un pago

// Función que se llama cuando se realiza un pago exitoso
function onPaymentSuccess(username, amount, serviceType) {
    // Guardamos los datos de pago en la variable
    lastPaymentData = { username, amount, serviceType };

    // Muestra un mensaje de éxito al usuario
    swal({
        title: "¡Éxito!",
        text: `Pago de ${amount} realizado exitosamente para ${serviceType}.`,
        icon: "success",
        button: "Aceptar",
    }).then(() => {
        // Muestra el botón de impresión después de un pago exitoso
        document.getElementById('print-button').style.display = 'block';
    });
}

// Función para manejar la impresión del PDF
function printPDF() {
    if (lastPaymentData) {
        // Si hay datos de pago, genera el PDF
        generatePDF(lastPaymentData.username, lastPaymentData.amount, lastPaymentData.serviceType);
    } else {
        // Si no hay datos disponibles, muestra un mensaje de advertencia
        swal({
            title: "Atención",
            text: "No hay datos disponibles para imprimir.",
            icon: "warning",
        });
    }
}

// Simulación de un pago (puedes integrar este código con tu lógica de backend)
document.getElementById('payment-form').addEventListener('submit', async function (event) {
    event.preventDefault();
    
    const formValues = {
        servicio: document.getElementById('servicio').value,
        monto: document.getElementById('monto').value,
        username: 'usuarioEjemplo' // Puedes obtenerlo de localStorage o de la sesión
    };

    const errors = validate(formValues, constraints);

    if (errors) {
        const errorMessages = Object.values(errors).map(error => error.join(", ")).join("\n");
        swal({
            title: "Oops",
            text: errorMessages,
            icon: "error",
        });
        return;
    }

    const monto = parseFloat(formValues.monto);
    const tipoServicio = formValues.servicio;

    // Realizamos la solicitud al servidor para procesar el pago
    const response = await fetch('/PaymentServlet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            username: formValues.username,
            servicio: tipoServicio,
            monto: monto
        })
    });

    const result = await response.json();

    if (result.status === "success") {
        // Si el pago fue exitoso, llama a la función onPaymentSuccess
        onPaymentSuccess(result.username, result.amount, result.serviceType);
    } else {
        // Si hubo un error en el pago, muestra un mensaje
        swal({
            title: "Error",
            text: result.message,
            icon: "error",
        });
    }
});
